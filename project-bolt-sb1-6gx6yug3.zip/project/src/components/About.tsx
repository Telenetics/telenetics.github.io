import React from 'react';
import { Award, Users, Lightbulb, Target } from 'lucide-react';

const About = () => {
  const stats = [
    { number: '500+', label: 'Projects Completed' },
    { number: '10+', label: 'Years Experience' },
    { number: '50+', label: 'Miles of Fiber Installed' },
    { number: '24/7', label: 'Emergency Support' }
  ];

  const values = [
    {
      icon: Award,
      title: 'Quality Excellence',
      description: 'We maintain the highest standards in every project, ensuring reliable and durable installations.'
    },
    {
      icon: Users,
      title: 'Expert Team',
      description: 'Our certified technicians bring years of experience and specialized knowledge to every job.'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'We stay current with the latest technologies and best practices in fiber optic construction.'
    },
    {
      icon: Target,
      title: 'Customer Focus',
      description: 'Your success is our priority. We work closely with clients to exceed expectations.'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              About <span className="text-red-600">FiberTech Pro</span>
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              With over a decade of experience in fiber optic construction, FiberTech Pro has established 
              itself as a trusted leader in telecommunications infrastructure. We specialize in delivering 
              high-quality, reliable fiber optic solutions that connect communities and businesses to the 
              digital future.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Our team of certified professionals combines technical expertise with a commitment to 
              excellence, ensuring every project is completed on time, within budget, and to the highest 
              industry standards.
            </p>
            
            {/* Stats */}
            <div className="grid grid-cols-2 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-3xl font-bold text-red-600 mb-2">{stat.number}</div>
                  <div className="text-gray-700 font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img
              src="https://images.pexels.com/photos/1181346/pexels-photo-1181346.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
              alt="Fiber optic construction team"
              className="w-full h-96 object-cover rounded-2xl shadow-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
          </div>
        </div>

        {/* Values Section */}
        <div className="mt-20">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Our <span className="text-red-600">Values</span>
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center group">
                <div className="bg-gradient-to-br from-red-600 to-red-500 p-4 rounded-full w-20 h-20 
                              mx-auto mb-6 flex items-center justify-center group-hover:scale-110 
                              transition-transform duration-300">
                  <value.icon className="h-10 w-10 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-4">{value.title}</h4>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;