import React from 'react';
import { ArrowRight, CheckCircle } from 'lucide-react';

const Hero = () => {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center bg-gradient-to-br from-black via-gray-900 to-black">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
          alt="Fiber optic construction"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center bg-red-600/20 border border-red-600/30 rounded-full px-4 py-2 mb-6">
              <span className="text-red-400 text-sm font-medium">Professional Fiber Optic Construction</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Building Tomorrow's
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">
                Digital Infrastructure
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              We specialize in high-quality fiber optic cable installation, underground construction, 
              and network infrastructure solutions that connect communities to the future.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button
                onClick={scrollToContact}
                className="bg-gradient-to-r from-red-600 to-red-500 text-white px-8 py-4 rounded-lg font-semibold 
                         hover:from-red-700 hover:to-red-600 transition-all duration-300 transform hover:scale-105 
                         shadow-lg hover:shadow-xl flex items-center justify-center group"
              >
                Get Free Quote
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
              <button
                onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-2 border-gray-600 text-white px-8 py-4 rounded-lg font-semibold 
                         hover:border-red-500 hover:bg-red-500/10 transition-all duration-300"
              >
                View Services
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-red-500" />
                <span className="text-gray-300">Licensed & Insured</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-red-500" />
                <span className="text-gray-300">24/7 Emergency Service</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-red-500" />
                <span className="text-gray-300">10+ Years Experience</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-br from-red-600/20 to-transparent p-8 rounded-2xl backdrop-blur-sm border border-red-600/20">
              <img
                src="https://images.pexels.com/photos/1181269/pexels-photo-1181269.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop"
                alt="Fiber optic cables"
                className="w-full h-64 object-cover rounded-lg shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;