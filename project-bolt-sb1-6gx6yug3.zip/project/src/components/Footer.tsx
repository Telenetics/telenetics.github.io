import React from 'react';
import { Cable, Phone, Mail, MapPin, Clock } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-2 lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-gradient-to-r from-red-600 to-red-500 p-2 rounded-lg">
                <Cable className="h-8 w-8 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">FiberTech Pro</h3>
                <p className="text-gray-400 text-sm">Construction Excellence</p>
              </div>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Leading fiber optic construction company specializing in high-quality installations, 
              underground construction, and network infrastructure solutions.
            </p>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-red-500" />
                <span className="text-gray-300">(555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-red-500" />
                <span className="text-gray-300">info@fibertechpro.com</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Services</h4>
            <ul className="space-y-3">
              <li><a href="#services" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Fiber Optic Installation</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Network Infrastructure</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Underground Construction</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Maintenance & Repair</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Project Management</a></li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Home</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Services</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-red-500 transition-colors duration-300">About Us</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-red-500 transition-colors duration-300">Contact</a></li>
            </ul>
          </div>

          {/* Business Hours */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Business Hours</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <Clock className="h-4 w-4 text-red-500 mt-1" />
                <div>
                  <p className="text-gray-300">Mon - Fri: 8:00 AM - 6:00 PM</p>
                  <p className="text-gray-300">Saturday: 8:00 AM - 4:00 PM</p>
                  <p className="text-gray-300">Sunday: Emergency Only</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 mt-4">
                <MapPin className="h-4 w-4 text-red-500" />
                <span className="text-gray-300">Nationwide Service</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © {currentYear} FiberTech Pro. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-red-500 transition-colors duration-300 text-sm">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-red-500 transition-colors duration-300 text-sm">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-red-500 transition-colors duration-300 text-sm">
                License Info
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;