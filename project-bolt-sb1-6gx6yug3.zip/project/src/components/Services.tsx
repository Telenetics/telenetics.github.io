import React from 'react';
import { Cable, Zap, Wrench, Shield, Clock, MapPin } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Cable,
      title: 'Fiber Optic Installation',
      description: 'Professional installation of single-mode and multi-mode fiber optic cables for residential and commercial projects.',
      features: ['Underground cable laying', 'Aerial cable installation', 'Indoor/outdoor routing', 'Cable termination']
    },
    {
      icon: Zap,
      title: 'Network Infrastructure',
      description: 'Complete network infrastructure solutions including equipment installation and configuration.',
      features: ['Splice enclosures', 'Equipment racks', 'Power systems', 'Environmental controls']
    },
    {
      icon: Wrench,
      title: 'Maintenance & Repair',
      description: '24/7 emergency repair services and preventive maintenance to keep your network running smoothly.',
      features: ['Emergency repairs', 'Cable fault location', 'System upgrades', 'Performance testing']
    },
    {
      icon: Shield,
      title: 'Underground Construction',
      description: 'Specialized underground construction services including trenching, boring, and conduit installation.',
      features: ['Directional boring', 'Trenching services', 'Conduit installation', 'Utility locating']
    },
    {
      icon: Clock,
      title: 'Project Management',
      description: 'End-to-end project management ensuring timely delivery and quality standards.',
      features: ['Site surveys', 'Permit acquisition', 'Progress tracking', 'Quality assurance']
    },
    {
      icon: MapPin,
      title: 'Site Planning & Design',
      description: 'Comprehensive site planning and network design services tailored to your specific needs.',
      features: ['Route surveys', 'Network design', 'Cost estimation', 'Feasibility studies']
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our <span className="text-red-600">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We provide comprehensive fiber optic construction services, from initial planning 
            to final installation and ongoing maintenance.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 
                       transform hover:-translate-y-2 border border-gray-200 overflow-hidden group"
            >
              <div className="p-8">
                <div className="bg-gradient-to-br from-red-600 to-red-500 p-3 rounded-lg w-fit mb-6 
                              group-hover:scale-110 transition-transform duration-300">
                  <service.icon className="h-8 w-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-700">
                      <div className="w-2 h-2 bg-red-500 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="bg-gradient-to-r from-red-600 to-red-500 h-2 transform scale-x-0 
                            group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;